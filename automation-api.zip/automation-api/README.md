README

# RUN All features in CORE Folder
behave -D urlcore=https://dev.api.core.helixcore.com -D user=admin@engeni.com -D pass=engeni -D pin=0000 ../features/Core/

# RUN one feature in CORE Folder
behave -D urlcore=https://dev.api.core.helixcore.com -D user=admin@engeni.com -D pass=engeni -D pin=0000 ../features/Core/test000_Login.feature  ../features/Core/test001_CRUD_User.feature

-----------------------------------------------------------------------------------------------------
# RUN Login feature from CORE and all features in DISPENSARY
 behave -D urlcore=https://dev.api.core.helixcore.com -D urldisp=https://dev.api.dispensary.helixcore.com -D user=admin@engeni.com -D pass=engeni -D pin=0000 ../features/Core/test000_Login.feature ../features/Dispensary/


# RUN All features in DISPENSARY Folder
behave -D urldisp=https://dev.api.dispensary.helixcore.com -D user=admin@engeni.com -D pass=engeni -D pin=0000 ../features/Dispensary/


# RUN one feature in DISPENSARY Folder
behave -D urldisp=https://dev.api.dispensary.helixcore.com -D user=admin@engeni.com -D pass=engeni -D pin=0000 ../features/Dispensary/test000_Login.feature  ../features/Dispensary/test001_CRUD_Product.feature

-----------------------------------------------------------------------------------------------------


# RUN All Features of the app
behave -D urlcore=https://dev.api.core.helixcore.com -D urldisp=https://dev.api.dispensary.helixcore.com -D user=admin@engeni.com -D pass=engeni -D pin=0000 ../features/

-----------------------------------------------------------------------------------------------------

#RUN Toby features

behave -D urltoby=https://dev.api.toby.helixcore.com ../features/Toby
