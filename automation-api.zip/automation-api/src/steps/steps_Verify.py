import requests, json, time
from behave import given, then, when
from steps.steps_Main import basicStep
from steps import steps_Main, steps_Get, steps_Save, steps_Requests_Body

global_Variable = {}

class StepsVerify():

    @then(u'Verify Item name: "{Name}"')
    def Verify_Name_Item(context, Name):
        Itname = steps_Main.global_Variable['responseParse']['data']['name']
        assert Itname == Name

    @then(u'Verify user, Name: "{Name}" - Lastname: "{LastName}"')
    def Verify_User(self, Name, LastName):
        uName = steps_Main.global_Variable['responseParse']['data']['first_name']
        uLastname = steps_Main.global_Variable['responseParse']['data']['last_name']
        assert uName == Name
        assert uLastname == LastName

    @then(u'Verify item DELETED: "{Item}"')
    def Verify_item_DEL(self, Item):
        messagedel = steps_Main.global_Variable['responseParse']['error']['message']
        messagedelset = "Resource " + Item + " " + steps_Get.global_Variable['ID'] + " not found"
        assert messagedel.upper() == messagedelset.upper()

    @then(u'Verify role, Name: "{Name}" - Description: "{Desc}"')
    def Verify_Role(self,Name,Desc):
        rName = steps_Main.global_Variable['responseParse']['data']['name']
        rDesc = steps_Main.global_Variable['responseParse']['data']['desc']
        assert rName == Name
        assert rDesc == Desc

    @then(u'Verify location, Name: "{Name}" - address1: "{address1}"')
    def Verify_Location(self,Name,address1):
        lName = steps_Main.global_Variable['responseParse']['data']['name']
        address = steps_Main.global_Variable['responseParse']['data']['address1']
        assert lName == Name
        assert address == address1

    @then(u'Verify Profile Type: "{profiletype}"')
    def Verify_profile_type(self, profiletype):
        protype = steps_Main.global_Variable['responseParse']['data']['profiles'][0]['profile_type']
        assert protype == profiletype

    @then(u'Verify Patient with Caregiver')
    def Verify_patient_with_Caregiver(self):
        Idcareg = steps_Main.global_Variable['responseParse']['data']['profiles'][0]['caregiver']['id']
        Idcuscar = steps_Main.global_Variable['responseParse']['data']['profiles'][0]['caregiver']['customer_id']
        NameProfileT = steps_Main.global_Variable['responseParse']['data']['profiles'][0]['caregiver']['profile_type']
        assert str(Idcareg) == steps_Save.global_Variable['ID_Caregiver']
        assert str(Idcuscar) == steps_Save.global_Variable['ID_Customer_Caregiver']
        assert NameProfileT == "CAREGIVER"

    @then(u'Verify driver, Name: "{Name}" - Lastname: "{LastName}"')
    def Verify_Driver(self, Name, LastName):
        uName = steps_Main.global_Variable['responseParse']['data']['firstname']
        uLastname = steps_Main.global_Variable['responseParse']['data']['lastname']
        assert uName == Name
        assert uLastname == LastName

    @then(u'Verify Status Audit "{Staudit}" and Status Details Audit "{Stadetail}"')
    def Verify_status_audit(self, Staudit, Stadetail):
        auditST = steps_Main.global_Variable['responseParse']['data']['status']
        detailST = steps_Main.global_Variable['responseParse']['data']['batch_audit_details'][0]['status']
        assert auditST == Staudit
        assert detailST == Stadetail

    @then(u'Verify New value audit')
    def Verify_audit_value(self):
        Upvalue = steps_Main.global_Variable['responseParse']['data']['batch_audit_details'][0]['new_value']
        assert str(Upvalue) == steps_Requests_Body.global_Variable['AuditNewValue']

    @then(u'Verify Room Quantity')
    def Verify_Room_Quantity(self):
        RoomQuantity = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['quantity']
        assert str(RoomQuantity) == steps_Requests_Body.global_Variable['AuditNewValue']

    @then(u'Verify Split Batch')
    def Verify_split_batch(self):
        ID = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['id']
        idbat = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['batch_id']
        ID1 = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][1]['id']
        idbat1 = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][1]['batch_id']
        assert steps_Get.global_Variable['ID_Batches1'] == ID
        assert steps_Get.global_Variable['ID_Batch1'] == str(idbat)
        assert steps_Get.global_Variable['ID_Batches2'] == ID1
        assert steps_Get.global_Variable['ID_Batch2'] == str(idbat1)

    @then(u'Verify Combine Batch')
    def Verify_combine_batch(self):
        ID = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['id']
        idbat = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['batch_id']
        assert steps_Save.global_Variable['ID_Batches'] == str(ID)
        assert str(steps_Save.global_Variable['ID_Batch_Aux']) == str(idbat)

    @then(u'Verify Moved Batch')
    def Verify_moved_batch(self):
        ID = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['id']
        idbat = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['batch_id']
        roomb = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['rooms'][0]['id']
        assert str(steps_Get.global_Variable['ID_Batches0']) == str(ID)
        assert str(steps_Get.global_Variable['ID_Batch0']) == str(idbat)
        assert steps_Get.global_Variable['idroombs'] == str(roomb)

    @then(u'Verify Convert Batch')
    def Verify_Convert_batch(self):
        ID = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['id']
        idproc = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['product_id']
        roomb = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['rooms'][0]['id']
        idbat = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['batch_id']
        assert str(steps_Get.global_Variable['ID_Batches0']) == str(ID)
        assert str(steps_Get.global_Variable['ID_Batch0']) == str(idbat)
        assert str(steps_Save.global_Variable['ID_Room']) == str(roomb)
        assert str(steps_Get.global_Variable['ID_Product']) == str(idproc)

    @then(u'Verify User already assigned a till')
    def Verify_assigned_till(self):
        messageBody = steps_Main.global_Variable['responseParse']['error']['message']
        messageOrigin = "The entity can't create a till because the user already has an assigned till"
        assert messageOrigin == messageBody

    @then(u'Verify open till, with amount: {amountill}')
    def Verify_open_till(self, amountill):
        idtill = steps_Main.global_Variable['responseParse']['data']['id']
        userassigned = steps_Main.global_Variable['responseParse']['data']['assigned_user_id']
        status = steps_Main.global_Variable['responseParse']['data']['status']
        cashtill = steps_Main.global_Variable['responseParse']['data']['cash']
        assert str(steps_Get.global_Variable['ID']) == str(idtill)
        assert str(steps_Save.global_Variable['ID_User']) == str(userassigned)
        assert str(status) == "OPEN"
        assert str(cashtill) == str(amountill)

    @then(u'Verify Charge: {PayMeth}')
    def Verify_charge_strp(self, PayMeth):
        idpayref = steps_Main.global_Variable['responseParse']['data'][0]['payment_reference']['id']
        methodpay = steps_Main.global_Variable['responseParse']['data'][0]['payment_method']['id']
        assert str(idpayref) == str(steps_Get.global_Variable['Toby_ID_payment_reference'])
        assert str(methodpay) == str(PayMeth)

    @then(u'Verify Payment Method, ID: "{idPayMet}" - Name: "{namePayMet}"')
    def Verify_payment_method(self, idPayMet, namePayMet):
        idpay = steps_Main.global_Variable['responseParse']['data'][0]['id']
        namepay = steps_Main.global_Variable['responseParse']['data'][0]['name']
        assert str(idpay) == str(idPayMet)
        assert str(namepay) == str(namePayMet)

    @then(u'Verify Customer, Customer_Checkin: "{Name}" - Lastname: "{LastName}"')
    def Verify_Customer(self, Name, LastName):
        for Customer in steps_Main.global_Variable['responseParse']['data']['data']:
            if (Customer['serving_number']['customer_id'] == str(steps_Save.global_Variable['ID_Customer_Patient'])):
                assert Customer['serving_number']['status'] == "CHECKED_IN"
                assert Customer['first_name'] == Name
                assert Customer['last_name'] == LastName
                break

    @then(u'Verify Checkout Customer')
    def Verify_Checkout_Customer(self):
        datacheckout  = steps_Main.global_Variable['responseParse']['data']['serving_number']
        assert datacheckout == None

    @then(u'Verify discount quantity batch')
    def Verify_discount_batch(self):
        qbatch = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['quantity']
        sumq = steps_Requests_Body.global_Variable['qprobatch'] + qbatch
        assert sumq == 100

    @then(u'Verify Order confirm')
    def Verify_order_confirm(self):
        custorder = steps_Main.global_Variable['responseParse']['data']['data'][0]['customer_id']
        statusorder = steps_Main.global_Variable['responseParse']['data']['data'][0]['status']
        qtyorder = steps_Main.global_Variable['responseParse']['data']['data'][0]['order_items'][0]['quantity']
        batchorder = steps_Main.global_Variable['responseParse']['data']['data'][0]['order_items'][0]['batch_barcode_uid']
        assert str(custorder) == str(steps_Save.global_Variable['ID_Customer_Patient'])
        assert str(statusorder) == "PAID"
        assert str(qtyorder) == str(steps_Requests_Body.global_Variable['qprobatch'])
        assert str(batchorder) == str(steps_Get.global_Variable['ID_Batch_Aux'])

    @then(u'Verify discounts')
    def Verify_discounts(self):
        amountver = steps_Main.global_Variable['responseParse']['data']['data'][0]['applied_discounts'][0]['amount']
        idiscount = steps_Main.global_Variable['responseParse']['data']['data'][0]['applied_discounts'][0]['discount_id']
        assert str(amountver) == str(steps_Requests_Body.global_Variable['Per_discount'])
        assert str(idiscount) == str(steps_Get.global_Variable['M_Discount_Per'])

    @then(u'Verify Batch Refunded')
    def Verify_batch_refunded(self):
        for batchre in steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['rooms']:
            if (batchre['room_type'] == 'SALES_FLOOR'):
                qbatchsale = batchre['quantity']
            elif (batchre['room_type'] == 'REFUND_RESTOCK_ROOM'):
                qbatchrefund = batchre['quantity']
        sumq = steps_Requests_Body.global_Variable['qprobatch'] + qbatchsale + qbatchrefund
        assert sumq == 100

    @then(u'Verify Quantity Batch')
    def Verify_Quantity_Batch(self):
        qbatch = steps_Main.global_Variable['responseParse']['data']['data'][0]['batches'][0]['quantity']
        assert qbatch == 100


    @then(u'Verify Order Voided')
    def Verify_Order_Voided(self):
        statusvoid = steps_Main.global_Variable['responseParse']['data']['status']
        assert str(statusvoid) == "CANCEL"

    @then(u'Verify Batch History, operation: "{opname}"')
    def Verify_batch_refunded(self, opname):
        for batchist in steps_Main.global_Variable['responseParse']['data']['data']:
            if (batchist['action'] == str(opname)):
                actionbat = batchist['action']
                batchid = batchist['batch_id']
                break
        assert actionbat == str(opname)
        assert str(batchid) == steps_Get.global_Variable['ID_Batches']