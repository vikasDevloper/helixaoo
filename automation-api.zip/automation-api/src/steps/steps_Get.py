import os

from behave import *
from steps import steps_Main, steps_Save, steps_Requests_Body

global_Variable = {}

class stpGet():

    @given(u'Get Request Body in File TXT, Name: "{nameReq}"')
    def get_Request_Body(self, nameReq):
        path = steps_Main.dirlogs + steps_Main.global_Variable['fecha'] + "/" + steps_Main.global_Variable['hora'] + "/REQUEST"
        try:
            os.makedirs(path)
        except OSError:
            print("Creation of the directory %s failed" % path)
        else:
            print("Successfully created the directory %s" % path)
        f = open(path + "/" + nameReq + ".txt", "w+")
        f.write(steps_Requests_Body.http_request_body['RequestBody'])
        f.close()

    @given(u'Get Endpoint in File TXT, Name: "{nameEnd}"')
    def get_Endpoint_Body(self, nameEnd):
        path = steps_Main.dirlogs + steps_Main.global_Variable['fecha'] + "/" + steps_Main.global_Variable['hora'] + "/ENDPOINT"
        try:
            os.makedirs(path)
        except OSError:
            print("Creation of the directory %s failed" % path)
        else:
            print("Successfully created the directory %s" % path)
        f = open(path + "/" + nameEnd + ".txt", "w+")
        urlEnd = steps_Main.global_Variable['urlapi'] + steps_Main.global_Variable['Endpoint'] + global_Variable['ID'] + steps_Main.global_Variable['Params']
        f.write(urlEnd)
        f.close()

    @then(u'Get access Token')
    def get_Token(self):
        global_Variable['ACToken'] = steps_Main.global_Variable['responseParse']['data']['access_token']

    @then(u'Get Username')
    def get_Username(self):
        steps_Requests_Body.global_Variable['User_Mail'] = steps_Main.global_Variable['responseParse']['data']['email']

    @then(u'Get ID Item')
    def get_ID_Item(self):
        idItem = steps_Main.global_Variable['responseParse']['data']['id']
        IditemPut = str(idItem)
        global_Variable['ID'] = IditemPut

    @then(u'Get ID account')
    def get_IDaccount(self):
        idaccount = steps_Main.global_Variable['responseParse']['data']['account_id']
        global_Variable['accoput'] = str(idaccount)

    @then(u'Get ID Location')
    def get_IDLocation(self):
        idLocation = steps_Main.global_Variable['responseParse']['data']['location_id']
        global_Variable['locationput'] = str(idLocation)

    @then(u'Get ID Tax')
    def get_ID_Tax(self):
        idTax = steps_Main.global_Variable['responseParse']['data']['taxes'][0]['id']
        global_Variable['idTaxPut'] = str(idTax)

    @then(u'Get ID Batch')
    def get_id_batch(self):
        Idbat = steps_Main.global_Variable['responseParse']['data']['batches'][0]['batch_id']
        global_Variable['ID_Batch'] = str(Idbat)
        global_Variable['ID_Batch_Aux'] = global_Variable['ID_Batch']
        global_Variable['ID'] = ""

    @then(u'Get ID Batch Audit Details')
    def get_id_batchAudit(self):
        Idbatau = steps_Main.global_Variable['responseParse']['data']['batch_audit_details'][0]['id']
        global_Variable['ID_Batch_Audit'] = str(Idbatau)

    @then(u'Get ID Batches')
    def get_id_batches(self):
        Idbat = steps_Main.global_Variable['responseParse']['data']['batches'][0]['id']
        global_Variable['ID_Batches'] = str(Idbat)

    @then(u'Get ID Batches, Position "{position}"')
    def get_id_batches_position(self, position):
        Idbat = steps_Main.global_Variable['responseParse']['data'][int(position)]['id']
        Idbatch = steps_Main.global_Variable['responseParse']['data'][int(position)]['batch_id']
        global_Variable['ID_Batches' + str(position)] = Idbat
        global_Variable['ID_Batch' + str(position)] = str(Idbatch)

    @then(u'Get ID Room in Batch')
    def get_id_room_batch(self):
        idroomb = steps_Main.global_Variable['responseParse']['data'][0]['rooms'][0]['id']
        global_Variable['idroombs'] = str(idroomb)

    @then(u'Get IDs Convert Batch')
    def get_ids_convertbatch(self):
        global_Variable['ID_Batches0'] = steps_Main.global_Variable['responseParse']['data'][0]['id']
        global_Variable['ID_Product'] = steps_Main.global_Variable['responseParse']['data'][0]['product_id']
        global_Variable['ID_Batch0'] = steps_Main.global_Variable['responseParse']['data'][0]['batch_id']
        roomaux = steps_Main.global_Variable['responseParse']['data'][0]['rooms'][0]['id']
        steps_Save.global_Variable['ID_Room'] = str(roomaux)

    @then(u'Get Total Cash in Safe')
    def get_total_cash(self):
        global_Variable['Cash_Safe'] = steps_Main.global_Variable['responseParse']['data']['data'][0]['cash']

    @then(u'Get ID Role User: "{rol}"')
    def get_role(self,rol):
        for role in steps_Main.global_Variable['responseParse']['data']['data']:
            if (role['name'] == rol):
                global_Variable['ID_Role_User'] = role['id']
                break

    @then(u'Get payment ID')
    def get_payID_Toby(self):
        Idpay = steps_Main.global_Variable['responseParse']['payment']['id']
        global_Variable['ID'] = str(Idpay)

    @then(u'Get payment reference ID')
    def get_payrefID_Toby(self):
        global_Variable['Toby_ID_payment_reference'] = steps_Main.global_Variable['responseParse']['payment']['reference_id']
        #['payment_reference']['id']

    @then(u'Get Sale Room ID')
    def get_sale_room(self):
        for room in steps_Main.global_Variable['responseParse']['data']['data']:
            if (room['room_type'] == 'SALES_FLOOR'):
                global_Variable['Sale_Room_ID'] = room['id']
                steps_Save.global_Variable['ID_Room'] = str(global_Variable['Sale_Room_ID'])
                break

    @then(u'Get Order Number')
    def get_order_number(self):
        ornumb = steps_Main.global_Variable['responseParse']['data']['order_number']
        global_Variable['Order_number'] = str(ornumb)

    @then(u'Get Manual Discount ID percentage')
    def get_manual_discount(self):
        for mdiscount in steps_Main.global_Variable['responseParse']['data']:
            if (mdiscount['name'] == 'POS Per-Order Percentage Discount'):
                global_Variable['M_Discount_Per'] = mdiscount['id']
                global_Variable['Scope_discount'] = mdiscount['scope']
                global_Variable['Codename_discount'] = mdiscount['codename']
                break

    @then(u'Get Order ID Global')
    def get_order_id(self):
        idorder = steps_Main.global_Variable['responseParse']['data']['order_items'][0]['id']
        global_Variable['ID_Order_Global'] = str(idorder)

    @then(u'Get ID Batch Type')
    def get_batch_type(self):
        for btype in steps_Main.global_Variable['responseParse']['data']['data']:
            if (btype['name'] == 'Non-Marijuana Item'):
                global_Variable['ID_Batch_Type'] = btype['id']
                break