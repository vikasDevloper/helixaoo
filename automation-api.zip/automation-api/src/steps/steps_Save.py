from behave import *
from steps import steps_Get, steps_Main


global_Variable = {}

class stpSave():

    @then(u'Save ID Patient')
    def Save_Patient(self):
        idCuspat = steps_Main.global_Variable['responseParse']['data']['profiles'][0]['id']
        global_Variable['ID_Patient'] = str(idCuspat)

    @then(u'Save ID Caregiver')
    def Save_Caregiver(self):
        idCuscar = steps_Main.global_Variable['responseParse']['data']['profiles'][0]['id']
        global_Variable['ID_Caregiver'] = str(idCuscar)

    @then(u'Save ID Customer Patient')
    def Save_Custo_Patient(self):
        global_Variable['ID_Customer_Patient'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Customer Caregiver')
    def Save_Custo_Caregiver(self):
        global_Variable['ID_Customer_Caregiver'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Batch Combine')
    def Save_Brand(self):
        global_Variable['ID_Batch_Aux'] = steps_Main.global_Variable['responseParse']['data']['batch_id']

    @then(u'Save ID Brand')
    def Save_Brand(self):
        global_Variable['ID_Brand'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Strain')
    def Save_Strain(self):
        global_Variable['ID_Strain'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Vendor')
    def Save_Vendor(self):
        global_Variable['ID_Vendor'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Tax category')
    def Save_Tax_category(self):
        global_Variable['ID_Tax_category'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Member level')
    def Save_Member_level(self):
        global_Variable['ID_Member_level'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Product Category')
    def Save_Product_Category(self):
        global_Variable['ID_Product_Category'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Product')
    def Save_Product(self):
        global_Variable['ID_Product'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Room')
    def Save_Room(self):
        global_Variable['ID_Room'] = steps_Get.global_Variable['ID']
        global_Variable['ID_Room_Aux'] = global_Variable['ID_Room']

    @then(u'Save ID Room2')
    def Save_Room2(self):
        global_Variable['ID_Room'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Batches')
    def Save_Batch(self):
        global_Variable['ID_Batches'] = steps_Get.global_Variable['ID']
        steps_Get.global_Variable['ID_Batches'] = global_Variable['ID_Batches']

    @then(u'Save ID User for new login')
    def Save_IDuser(self):
        global_Variable['ID_New_User_Log'] = steps_Get.global_Variable['ID']
        global_Variable['ID_User'] = global_Variable['ID_New_User_Log']

    @then(u'Save ID User Login')
    def Save_IDuserLog(self):
        global_Variable['ID_User_Login'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Till')
    def Save_IDuserLog(self):
        global_Variable['ID_Till'] = steps_Get.global_Variable['ID']

    @then(u'Save ID Order')
    def Save_IDOder(self):
        global_Variable['ID_Order'] = steps_Get.global_Variable['ID']