import os
import random

import requests, json, time
from behave import given, then, when
from datetime import datetime
from steps import steps_Requests_Body, steps_Get

dirlogs = "../Logs/"
numRandom = str(random.randint(2, 100000))
global_Variable = {}

class basicStep():
    @given(u'Set URL API Core for console command')
    def setenvironment(self):
        global_Variable['urlapi'] = str(self.config.userdata.get("urlcore"))

    @given(u'Set URL API Dispensary for console command')
    def setenvironment(self):
        global_Variable['urlapi'] = str(self.config.userdata.get("urldisp"))

    @given(u'Set URL TOBY for console command')
    def setenvironment(self):
        global_Variable['urlapi'] = str(self.config.userdata.get("urltoby"))

    @given(u'Date Time for logs')
    def Fecha(self):
        ahora = datetime.now()
        global_Variable['fecha'] = ahora.strftime("%Y%m%d")
        global_Variable['hora'] = ahora.strftime("%H%M%S")
        self.path = dirlogs+global_Variable['fecha']+"/"+global_Variable['hora']
        try:
            os.makedirs(self.path)
        except OSError:
            print("Creation of the directory %s failed" % self.path)
        else:
            print("Successfully created the directory %s" % self.path)

    @given(u'Clear Globals Variables')
    def  clear_Variables(self):
        steps_Get.global_Variable['ID'] = ""
        global_Variable['Params'] = ""
        steps_Get.global_Variable['ID_Batch'] = ""

    @given(u'Set api endpoint as "{api_endpoint}"')
    def endPoint_Logname(self, api_endpoint):
        global_Variable['Endpoint'] = api_endpoint


    @then(u'Response http code should be "{StatusCode}"')
    def step_impl(self, StatusCode):

        if global_Variable['Status_Code'] == StatusCode:
            assert global_Variable['Status_Code'] == StatusCode
            print('The code status is CORRECT: ' + global_Variable['Status_Code'])
        else:
            assert global_Variable['Status_Code'] == StatusCode
            print('The code status is INCORRECT: ' + global_Variable['Status_Code'])


    @then(u'Get Log, set Log Name: {logname}')
    def Get_Log(self, logname):
        global_Variable['Status_Code'] = str(self.response.status_code)
        responsetxt = self.response.text
        f = open(dirlogs + global_Variable['fecha'] + "/" + global_Variable['hora'] + "/" + logname + " - Status Code " + global_Variable['Status_Code'] + ".txt","w+")
        f.write(responsetxt)
        f.close()
        print(responsetxt)

    @given(u'Set endpoint params: "{params}"')
    def endpoint_params(self, params):
        endparams = str(params)
        global_Variable['Params'] = endparams



    @when(u'Set Method "{method_api}", Need Headers: "{headApi}", Need PinCode: "{opPin}"')
    def Method_Select(self, method_api, headApi, opPin):

        if method_api == "POST" and headApi == "NO" and opPin == "NO":
            self.response = requests.post(global_Variable['urlapi'] + global_Variable['Endpoint'], steps_Requests_Body.http_request_body['RequestBody'], headers ={"Content-Type":"application/json"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse

        elif method_api == "POST" and headApi == "YES" and opPin == "NO":
            self.response = requests.post(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'], steps_Requests_Body.http_request_body['RequestBody'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type":"application/json"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""


        elif method_api == "POST" and headApi == "YES" and opPin == "YES":
            self.response = requests.post(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'], steps_Requests_Body.http_request_body['RequestBody'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type": "application/json", "Pincode": f"{steps_Requests_Body.global_Variable['PinCod']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""

        elif method_api == "POST-NoContent" and headApi == "YES" and opPin == "YES":
            self.response = requests.post(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] +global_Variable['Params'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type": "application/json", "Pincode": f"{steps_Requests_Body.global_Variable['PinCod']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""

        elif method_api == "TOBYPOST" and headApi == "YES" and opPin == "NO":
            self.response = requests.post(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'], steps_Requests_Body.http_request_body['RequestBody'], headers={"X-Api-Token": f"{steps_Get.global_Variable['ACToken']}", "Content-Type":"application/json"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse

        elif method_api == "GET" and headApi == "YES" and opPin == "NO":
            self.response = requests.get(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'] + steps_Get.global_Variable['ID_Batch'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""
            steps_Get.global_Variable['ID_Batch'] = ""

        elif method_api == "TOBYGET" and headApi == "YES" and opPin == "NO":
            self.response = requests.get(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'], headers={"X-Api-Token": f"{steps_Get.global_Variable['ACToken']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse

        elif method_api == "PUT" and headApi == "YES" and opPin == "NO":
            self.response = requests.put(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'], steps_Requests_Body.http_request_body['RequestBody'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type": "application/json"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""

        elif method_api == "PUT" and headApi == "YES" and opPin == "YES":
            self.response = requests.put(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'], steps_Requests_Body.http_request_body['RequestBody'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type": "application/json", "Pincode": f"{steps_Requests_Body.global_Variable['PinCod']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""

        elif method_api == "PUT-NoContent" and headApi == "YES" and opPin == "NO":
            self.response = requests.put(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] + global_Variable['Params'], steps_Requests_Body.http_request_body['RequestBody'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type": "application/json"})
            global_Variable['Params'] = ""

        elif method_api == "PATCH" and headApi == "YES" and opPin == "NO":
            self.response = requests.patch(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'] +global_Variable['Params'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Content-Type": "application/json" })
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse
            global_Variable['Params'] = ""

        elif method_api == "DELETE" and headApi == "YES" and opPin == "NO":
            self.response = requests.delete(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse

        elif method_api == "DELETE" and headApi == "YES" and opPin == "YES":
            self.response = requests.delete(global_Variable['urlapi'] + global_Variable['Endpoint'] + steps_Get.global_Variable['ID'], headers={"Authorization": f"Bearer {steps_Get.global_Variable['ACToken']}", "Pincode": f"{steps_Requests_Body.global_Variable['PinCod']}"})
            self.responseParse = self.response.json()
            global_Variable['responseParse'] = self.responseParse

        else:
            print("Selection not found")