from behave import given, then, when
from steps import steps_Main, steps_Get, steps_Save
import requests, json, time, random


dirJson = "../JSON/"
http_request_body = {}
global_Variable = {}

class RequestsBody():

    @given(u'Set Json File: {JsonFile}')
    def file_Json(context, JsonFile):
        file = open(dirJson + JsonFile, 'r')
        json_input = file.read()
        request_json = json.loads(json_input)
        http_request_body['RequestBody'] = request_json


    @given(u'Set Json File Direct: {JsonFile}')
    def file_Json_Direct(context, JsonFile):
        file = open(dirJson + JsonFile, 'r')
        json_input = file.read()
        http_request_body['RequestBody'] = json_input

    @given(u'Set user for console command')
    def set_user(self):
        global_Variable['User_Mail'] = str(self.config.userdata.get("user"))
        global_Variable['Pass_User'] = str(self.config.userdata.get("pass"))
        global_Variable['PinCod'] = str(self.config.userdata.get("pin"))

    @given(u'Select Login Request Body')
    def login(self):
        self.jsonlogin = '{"email":"' + global_Variable['User_Mail'] + '","password":"' + global_Variable['Pass_User'] + '"}'
        http_request_body['RequestBody'] = self.jsonlogin

    @given(u'Select Role User Request Body')
    def user_role(self):
        body = '[' + str(steps_Get.global_Variable['ID_Role_User']) + ']'
        http_request_body['RequestBody'] = body

    @given(u'Select User Create Request Json')
    def user_Request(self):
        numRandom = str(random.randint(100001, 200000))
        jsoncreate = '{"id": "","avatar": null,"name": null,"email": "' + numRandom + '@gmail.com","password": "Engeniautomation1","pin_code": null,"profile": {"nickname": null,"first_name": "TEST","middle_name": null,"last_name": "TEST","birthday": "1980-02-15","mailing_address": null,"city": null,"state_id": null,"country_id": null,"company_email_address": "' + numRandom + '@gmail.com","personal_email": null,"phone_number": null,"gender": null,"drivers_license_number": null,"drivers_license_expiration": null,"occupational_license_number": null,"occupational_license_expiration": null,"hourly_rate": null,"zip": null},"first_name": "TEST","last_name": "AUTOMATION"}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Modify User Request Json')
    def Modify_user_Request(self):
        jsonput = '{"id":' + steps_Get.global_Variable['ID'] + ',"avatar":null,"name":null,"email":"' + steps_Main.numRandom + '@gmail.com","password":null,"pin_code":null,"profile":{"nickname":null,"first_name":null,"middle_name":null,"last_name":null,"birthday":"1980-02-15","mailing_address":null,"city":null,"state_id":null,"country_id":null,"company_email_address":"fekjfnkej@engeni.com","personal_email":null,"phone_number":null,"gender":null,"drivers_license_number":null,"drivers_license_expiration":null,"occupational_license_number":null,"occupational_license_expiration":null,"hourly_rate":null,"zip":null},"first_name":"MODIFIED","last_name":"AUTOMATION"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Location Request Json')
    def Modify_location_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","account_id":"' + steps_Get.global_Variable['accoput'] + '","name":"Test Python","address1":"Parque Chacabuco","address2":null,"city":"vicente lopez","state_id":61,"country_id":"US","zip":"10","phone":"","website":null,"fax":null,"email":null,"currency":"USD","default_lang":"en","date_format":"MM-DD-YYYY","user_id":23,"timezone_id":400,"created_by":23,"updated_by":null,"location_type":"RETAIL_RECREATIONAL","license_type": "Retail","limit_config":{"action_method":"ACTION_BLOCK","limit_hour_enabled":false,"time_apply_from":"07:00:00","time_apply_to":"22:00:00","action_limit_recreational_age":"ACTION_BLOCK","action_limit_medical_age":"ACTION_BLOCK","limit_recreational_age":18,"limit_medical_age":18},"license_number":"10","cumulative_pricing":1,"price_point_grouping":1,"post_tax_pricing":0,"pre_tax_pricing":1,"created_at":"2019-10-18T12:49:13.000000Z","updated_at":"2019-10-18T12:49:13.000000Z","_method":"PUT"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Product Category Request Json')
    def Modify_product_category_Request(self):
        jsonput = '{"account_id":"' + steps_Get.global_Variable['accoput'] + '","created_at":null,"deleted_at":null,"id":"' + steps_Get.global_Variable['ID'] + '","name":"MODIFIED AUTOMATION","shared":false,"updated_at":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Strain Request Json')
    def Modify_strain_Request(self):
        jsonput = '{"name":"Strain modified","strain_type_id":3,"rank":7,"account_id": "' + steps_Get.global_Variable['accoput'] + '","parent_id":7,"location_id": "' + steps_Get.global_Variable['locationput'] + '","updated_at":"2020-02-17T15:48:52+00:00","created_at":"2020-02-17T15:48:52+00:00","id": "' + steps_Get.global_Variable['ID'] + '","avatar_medium_url":null,"avatar_thumb_url":null,"avatar_original_url":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Vendor Request Json')
    def Modify_vendor_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","name":"Vendormation modified","address1":"Av del Libertador","address2":null,"city":"Buenos Aires","state":"Buenos Aires","country":"Argentina","zip":null,"phone1":null,"website":null,"license":"090017288","type":"VENDOR","account_id":"' + steps_Get.global_Variable['accoput'] + '","created_by":"3","updated_by":null,"deleted_by":null,"created_at":"2020-02-14T15:01:59+00:00","updated_at":"2020-02-14T15:01:59+00:00","parent_id":null,"location_id":"' + steps_Get.global_Variable['locationput'] + '"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Lab Request Json')
    def Modify_lab_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","name":"Laboratory modified","address1":"Av del Libertador","address2":null,"city":"Buenos Aires","state":"Buenos Aires","country":"Argentina","zip":null,"phone1":null,"website":null,"license":"4316821","type":"LABORATORY","account_id":"' + steps_Get.global_Variable['accoput'] + '","created_by":"3","updated_by":null,"deleted_by":null,"created_at":"2020-02-14T15:01:59+00:00","updated_at":"2020-02-14T15:01:59+00:00","parent_id":null,"location_id":"' + steps_Get.global_Variable['locationput'] + '"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Brand Request Json')
    def Modify_brand_Request(self):
        jsonput = '{"name":"Brand modified","account_id": ' + steps_Get.global_Variable['accoput'] + ',"location_id": ' + steps_Get.global_Variable['locationput'] + ',"is_fully_qualified":false,"updated_at":"2020-02-17T19:33:54+00:00","created_at":"2020-02-17T19:33:54+00:00","id":"' + steps_Get.global_Variable['ID'] + '","logo_medium_url":null,"logo_thumb_url":null,"logo_original_url":null,"vendors":[]}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Tax Category Request Json')
    def Modify_tax_category_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","name":"MODIFIED AUTOMATION","location_id":' + steps_Get.global_Variable['locationput'] + ',"account_id":' + steps_Get.global_Variable['accoput'] + ',"deleted_at":null,"created_at":"2019-10-23T17:23:15+00:00","updated_at":"2019-10-23T17:23:15+00:00","is_default":0,"overall_rate":"100%","taxes":[{"id":"' + steps_Get.global_Variable['idTaxPut'] + '","name":"MODIFIED AUTOMATION","rate":50,"type":"NORMAL","deleted_at":null,"account_id":' + steps_Get.global_Variable['accoput'] + ',"created_at":"2019-10-23T17:23:15+00:00","updated_at":"2019-10-23T17:23:15+00:00"}],"_method":"PUT"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Member Level Request Json')
    def Modify_member_level_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","name":"MODIFIED AUTOMATION","type":"PERCENTAGE","automatic_percentage_fallback":null,"rate":"10","location_id":' + steps_Get.global_Variable['locationput'] + ',"account_id":' + steps_Get.global_Variable['accoput'] + ',"created_at":"2019-10-23T17:17:17+00:00","updated_at":"2019-10-23T17:17:17+00:00","_method":"PUT"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Room Request Json')
    def Modify_room_Request(self):
        jsonput = '{"location_id": ' + steps_Get.global_Variable['locationput'] + ',"name":"Room modified","room_type":"NORMAL_ROOM","account_id": ' + steps_Get.global_Variable['accoput'] + ',"updated_at":"2020-02-17T18:25:11+00:00","created_at":"2020-02-17T18:25:11+00:00","id": "' + steps_Get.global_Variable['ID'] + '"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify, Customer to Caregiver, Request Json')
    def Modify_customer_to_caregiver_Request(self):
        jsonput = '{"id": "' + steps_Get.global_Variable['ID'] + '","first_name": "MODIFIED","middle_name": null,"last_name":"AUTOMATION","email":null,"birthday":"1943-08-25","phone": null,"cellphone": null,"cellphone_carrier": null,"id_is_temporary": false,"rec_num": null,"rec_exp_date": null,"dl_number": null,"dl_exp_date": null,"medical_customer": 0,"flat_discount_rate": null,"member_level_id": null,"tax_exempt": 0,"id_type": null,"id_number": null,"medical_card_number": null,"medical_card_expiration": null,"shows_checkin_note": false,"caregiver": null,"profiles":[{"id": "' + steps_Save.global_Variable['ID_Patient'] + '","customer_id": ' + steps_Get.global_Variable['ID'] + ',"doctor_active_license": 1,"profile_type": "PATIENT", "_destroy": true},{"medical_card_number": null,"medical_card_expiration": null,"customer_id": ' + steps_Get.global_Variable['ID'] + ', "profile_type": "CAREGIVER"}], "patient": null,"isCaregiver": false,"isPatient": true,"_method": "PUT"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify, Customer to Patient, Request Json')
    def Modify_customer_to_patient_Request(self):
        jsonput = '{"id": "' + steps_Get.global_Variable['ID'] + '","first_name": "MODIFIED","middle_name": null,"last_name":"AUTOMATION","email":null,"birthday":"1943-08-25","phone": null,"cellphone": null,"cellphone_carrier": null,"id_is_temporary": false,"rec_num": null,"rec_exp_date": null,"dl_number": null,"dl_exp_date": null,"medical_customer": 0,"flat_discount_rate": null,"member_level_id": null,"tax_exempt": 0,"id_type": null,"id_number": null,"medical_card_number": null,"medical_card_expiration": null,"shows_checkin_note": false,"caregiver": null,"profiles":[{"id": "' + steps_Save.global_Variable['ID_Caregiver'] + '","customer_id": ' + steps_Get.global_Variable['ID'] + ',"doctor_active_license": 1,"profile_type": "CAREGIVER", "_destroy": true},{"medical_card_number": null,"medical_card_expiration": null,"customer_id": ' + steps_Get.global_Variable['ID'] + ', "profile_type": "PATIENT"}], "patient": null,"isCaregiver": false,"isPatient": true,"_method": "PUT"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Add Patient Request Json')
    def Add_patient_Request(self):
        jsonput = '{"id": "' + steps_Save.global_Variable['ID_Customer_Caregiver'] + '","first_name": "TEST CAREGIVER","middle_name": null,"last_name":"AUTOMATION","email":null,"birthday":"1943-08-25","phone": null,"cellphone": null,"cellphone_carrier": null,"id_is_temporary": false,"rec_num": null,"rec_exp_date": null,"dl_number": null,"dl_exp_date": null,"medical_customer": 0,"flat_discount_rate": null,"member_level_id": null,"tax_exempt": 0,"id_type": null,"id_number": null,"medical_card_number": null,"medical_card_expiration": null,"account_id": ' + steps_Get.global_Variable['accoput'] + ',"shows_checkin_note": false,"caregiver": null,"profiles":[{"id": "' + steps_Save.global_Variable['ID_Caregiver'] + '","customer_id": ' + steps_Save.global_Variable['ID_Customer_Caregiver'] + ',"doctor_active_license": 1,"profile_type": "CAREGIVER", "patients":[{"patient_id":"' + steps_Save.global_Variable['ID_Patient'] + '"}]}], "patient": null,"isCaregiver": true,"isPatient": false,"_method": "PUT"}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Brand Create Request Json, invocation: "{num}"')
    def Brand_Request(self, num):
        jsoncreate = '{"name": "Brand Test' + num + steps_Main.numRandom + '","account_id": null,"location_id": null,"is_fully_qualified": false,"updated_at": null,"created_at": null,"id": null,"logo_medium_url": null,"logo_thumb_url": null,"logo_original_url": null,"vendors": []}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Strain Create Request Json, invocation: "{num}"')
    def Strain_Request(self, num):
        jsoncreate = '{"id": null,"name": "Strain Auto' + num + steps_Main.numRandom + '","strain_type_id": 3,"rank": 7,"avatar_file_name": "example_strain.png", "avatar_file_size": 16627,"avatar_content_type": "image/png", "avatar_variants": "[]","avatar_updated_at": "2019-07-22T21:16:30+00:00","account_id": 1,"deleted_by": null,"created_at": null,"updated_at": null,"parent_id": 7,"location_id": 1,"avatar_medium_url": "https://dev.static.dispensary.helixcore.com/strains/7/avatar/medium/example_strain.png","avatar_thumb_url": "https://dev.static.dispensary.helixcore.com/strains/7/avatar/thumb/example_strain.png","avatar_original_url": "https://dev.static.dispensary.helixcore.com/strains/7/avatar/original/example_strain.png"}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Vendor Create Request Json, invocation: "{num}"')
    def Vendor_Request(self, num):
        jsoncreate = '{"name": "Vendormation' + num + steps_Main.numRandom + '","type": "VENDOR","license": "090017288","website": null,"phone1": null,"address1": "Av del Libertador","city": "Buenos Aires","state": "Buenos Aires","country": "Argentina","phone2": null,"email": null,"zip": null}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Product Category Create Request Json, invocation: "{num}"')
    def Product_Category_Request(self, num):
        jsoncreate = '{"account_id": null,"created_at": null,"deleted_at": null,"id": null,"name": "TEST AUTOMATION' + num + steps_Main.numRandom + '","shared": false,"updated_at": null}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Room Create Request Json, invocation: "{num}"')
    def Room_Request(self, num):
        jsoncreate = '{"location_id": null,"name": "Room Autotest' + num + steps_Main.numRandom + '","room_type": "NORMAL_ROOM","account_id": null,"updated_at": null,"created_at": null,"id": null}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Product Non-Cannabis Create Request Json')
    def productCA_Request(self):
        jsonput = '{"account_id":"","batches":[],"brand":null,"brand_id":' + steps_Save.global_Variable['ID_Brand'] + ',"category":null,"product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + ',"created_at":null,"default_cost_per_unit":0,"deleted_at":null,"deleted_by":null,"id":null,"require_inventory":1,"marijuana":false,"medicated":0,"member_discount":0,"member_only":0,"name":"PRODUCT Non-Cannabis TEST' + steps_Main.numRandom + '","price":0,"strain_id":null,"strain":null,"tax_id":null,"tax":{},"type":null,"updated_at":null,"vendor":null,"vendor_id":' + steps_Save.global_Variable['ID_Vendor'] + ',"requires_weighing":1,"shareable":true,"metrc_weighable":false,"metrc_item_association":null,"prices":[{"id":null,"quantity":"50","price":100,"post_tax":"100","pre_excise":100,"tax_category_id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"member_level_id":' + steps_Save.global_Variable['ID_Member_level'] + ',"member_discount_id":null,"type":"RETAIL_MEDICAL","tax_category":{"id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"name":"TEST AUTOMATION","location_id":"' + steps_Get.global_Variable['locationput'] + '","account_id":"' + steps_Get.global_Variable['accoput'] + '","deleted_at":null,"created_at":"2019-07-22T21:16:28+00:00","updated_at":"2019-10-28T21:27:23+00:00","is_default":0,"is_exempt":0,"overall_rate":"","taxes":[]}}],"price_settings":{"id":null,"default_cost_per_unit":null,"price_point_by_usable_weight":0,"block_item_from_being_sold_below_cost_per_unit":0,"member_discount_eligible":1,"block_item_from_being_sold_at_zero_cost":0,"members_only_product":0},"packaging_detail":{"id":null,"ingredients":"","allergens":"","manufacturer_id":null,"cultivator_id":null,"activation_time":"","activation_time_unit":"","lasting_effect_time":"","lasting_effect_time_unit":"","recreational_customer_label_template_id":null,"medical_customer_label_template_id":null,"inventory_label_template_id":null,"suggested_amount":null,"serving_size":null,"serving_size_unit":"","serving_size_of_the_container":null,"product_id":null},"unit":"g","weight_per_unit_measure":"g","batch_type_id":1,"usable_weight":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Product Non-Cannabis Request Json')
    def Modify_productNCA_Request(self):
        jsonput = '{"id":' + steps_Save.global_Variable['ID_Product'] + ',"name":"MODIFIED TEST","product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + ',"strain_id":null,"batch_type_id":1,"brand_id":' + steps_Save.global_Variable['ID_Brand'] + ',"vendor_id":' + steps_Save.global_Variable['ID_Vendor'] + ',"product_group_id":null,"requires_weighing":1,"require_inventory":1,"marijuana":true,"usable_weight":null,"unit":"g","weight_per_unit":null,"weight_per_unit_measure":"g","quantity":null,"barcode":null,"image_file_name":null,"image_file_size":null,"image_content_type":null,"image_variants":null,"image_updated_at":null,"account_id":1,"created_by":3,"updated_by":null,"deleted_by":null,"deleted_at":null,"created_at":"2020-02-20T15:20:33+00:00","updated_at":"2020-02-20T15:20:33+00:00","parent_id":null,"location_id":1,"is_fully_qualified":1,"image_medium_url":null,"image_thumb_url":null,"image_original_url":null,"cost":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Product Cannabis Create Request Json')
    def productNCA_Request(self):
        jsonput = '{"account_id":"","batches":[],"brand":null,"brand_id":' + steps_Save.global_Variable['ID_Brand'] + ',"category":null,"product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + ',"created_at":null,"default_cost_per_unit":0,"deleted_at":null,"deleted_by":null,"id":null,"require_inventory":0,"marijuana":1,"medicated":0,"member_discount":0,"member_only":0,"name":"PRODUCT Cannabis TEST","price":0,"strain_id":' + steps_Save.global_Variable['ID_Strain'] + ',"strain":null,"tax_id":null,"tax":{},"type":null,"updated_at":null,"vendor":null,"vendor_id":' + steps_Save.global_Variable['ID_Vendor'] + ',"requires_weighing":1,"shareable":true,"metrc_weighable":false,"metrc_item_association":null,"prices":[{"id":null,"quantity":"20","price":50,"post_tax":"50","pre_excise":50,"tax_category_id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"member_level_id":' + steps_Save.global_Variable['ID_Member_level'] + ',"member_discount_id":null,"type":"RETAIL_MEDICAL","tax_category":{"id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"name":"TEST AUTOMATION","location_id":"' + steps_Get.global_Variable['locationput'] + '","account_id":"' + steps_Get.global_Variable['accoput'] + '","deleted_at":null,"created_at":"2019-07-22T21:16:28+00:00","updated_at":"2019-10-28T21:27:23+00:00","is_default":0,"is_exempt":0,"overall_rate":"","taxes":[]}}],"price_settings":{"id":null,"default_cost_per_unit":"100","price_point_by_usable_weight":0,"block_item_from_being_sold_below_cost_per_unit":0,"member_discount_eligible":1,"block_item_from_being_sold_at_zero_cost":0,"members_only_product":false},"packaging_detail":{"id":null,"ingredients":"","allergens":"","manufacturer_id":null,"cultivator_id":null,"activation_time":"","activation_time_unit":"","lasting_effect_time":"","lasting_effect_time_unit":"","recreational_customer_label_template_id":null,"medical_customer_label_template_id":null,"inventory_label_template_id":null,"suggested_amount":null,"serving_size":null,"serving_size_unit":"","serving_size_of_the_container":null,"product_id":null},"unit":"g","weight_per_unit_measure":"g","batch_type_id":1,"usable_weight":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Product Cannabis Request Json')
    def Modify_productCA_Request(self):
        jsonput = '{"id":' + steps_Save.global_Variable['ID_Product'] + ',"name":"MODIFIED TEST","product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + ',"strain_id":' + steps_Save.global_Variable['ID_Strain'] + ',"batch_type_id":1,"brand_id":' + steps_Save.global_Variable['ID_Brand'] + ',"vendor_id":' + steps_Save.global_Variable['ID_Vendor'] + ',"product_group_id":null,"requires_weighing":1,"require_inventory":1,"marijuana":true,"usable_weight":null,"unit":"g","weight_per_unit":null,"weight_per_unit_measure":"g","quantity":null,"barcode":null,"image_file_name":null,"image_file_size":null,"image_content_type":null,"image_variants":null,"image_updated_at":null,"account_id":1,"created_by":3,"updated_by":null,"deleted_by":null,"deleted_at":null,"created_at":"2020-02-20T15:20:33+00:00","updated_at":"2020-02-20T15:20:33+00:00","parent_id":null,"location_id":1,"is_fully_qualified":1,"image_medium_url":null,"image_thumb_url":null,"image_original_url":null,"cost":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Batch Create Request Json')
    def Batch_Request(self):
        jsoncreate = '{"type":"INBOUND","sourceable_type":"LOCATION_TRANSFER","sourceable_id":1,"sub_total":5000,"total":5000,"tax":0,"status":"COMPLETED","is_payable":false,"payments":[],"discount":{"name":"","amount":0,"post_tax":true,"type":"PERCENTAGE"},"fees":{"name":"","amount":0,"post_tax":true,"type":"PERCENTAGE"},"notes":[],"transfer_items":[{"product_id":' + steps_Save.global_Variable['ID_Product'] + ',"expiration_date":"","batch_price_level_id":3,"quantity":100,"price_per_unit":50,"cost_per_unit":50,"subtotal":5000,"total":5000,"tax_category_id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"tax_total":0,"discount":{"name":"","amount":0,"post_tax":false,"type":"PERCENTAGE"},"fees":{"name":"","amount":0,"post_tax":false,"type":"PERCENTAGE"},"sample":{"results":[]},"usable_weight":0,"unit":"g","weight_per_unit":null,"weight_per_unit_measure":"g","rooms":[{"room_id":' + steps_Save.global_Variable['ID_Room'] + ',"quantity":100}]}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Product Cannabis Create Request Json for Batch, invocation: "{num}"')
    def productCA2_Request(self, num):
        jsonput = '{"account_id":"","batches":[],"brand":null,"brand_id":' + steps_Save.global_Variable['ID_Brand'] + ',"category":null,"product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + ',"created_at":null,"default_cost_per_unit":0,"deleted_at":null,"deleted_by":null,"id":null,"require_inventory":0,"marijuana":1,"medicated":0,"member_discount":0,"member_only":0,"name":"PRODUCT Cannabis TEST' + num + steps_Main.numRandom + '","price":0,"strain_id":' + steps_Save.global_Variable['ID_Strain'] + ',"strain":null,"tax_id":null,"tax":{},"type":null,"updated_at":null,"vendor":null,"vendor_id":' + steps_Save.global_Variable['ID_Vendor'] + ',"requires_weighing":1,"shareable":true,"metrc_weighable":false,"metrc_item_association":null,"prices":[{"id":null,"quantity":"20","price":50,"post_tax":"50","pre_excise":50,"tax_category_id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"member_level_id":null,"member_discount_id":null,"type":"RETAIL_MEDICAL","tax_category":{"id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"name":"TEST AUTOMATION","location_id":"' + steps_Get.global_Variable['locationput'] + '","account_id":"' + steps_Get.global_Variable['accoput'] + '","deleted_at":null,"created_at":"2019-07-22T21:16:28+00:00","updated_at":"2019-10-28T21:27:23+00:00","is_default":0,"is_exempt":0,"overall_rate":"100%","taxes":[{"id": ' + steps_Get.global_Variable['idTaxPut'] + ',"name": "TEST AUTOMATION","rate": 100,"tax_category_id": ' + steps_Save.global_Variable['ID_Tax_category'] + ',"type": "NORMAL","deleted_at": null,"account_id": 1,"created_at": "2020-04-13T18:52:07+00:00","updated_at": "2020-04-13T18:52:07+00:00"}]}}],"price_settings":{"id":null,"default_cost_per_unit":"100","price_point_by_usable_weight":0,"block_item_from_being_sold_below_cost_per_unit":0,"member_discount_eligible":true,"block_item_from_being_sold_at_zero_cost":0,"members_only_product":false},"packaging_detail":{"id":null,"ingredients":"","allergens":"","manufacturer_id":null,"cultivator_id":null,"activation_time":"","activation_time_unit":"","lasting_effect_time":"","lasting_effect_time_unit":"","recreational_customer_label_template_id":null,"medical_customer_label_template_id":null,"inventory_label_template_id":null,"suggested_amount":null,"serving_size":null,"serving_size_unit":"","serving_size_of_the_container":null,"product_id":null},"unit":"g","weight_per_unit_measure":"g","batch_type_id":1,"usable_weight":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Product Non-Cannabis Create Request Json for Batch, invocation: "{num}"')
    def productCA_Request(self,num):
        jsonput = '{"account_id":"","batches":[],"brand":null,"brand_id":' + steps_Save.global_Variable['ID_Brand'] + ',"category":null,"product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + ',"created_at":null,"default_cost_per_unit":0,"deleted_at":null,"deleted_by":null,"id":null,"require_inventory":1,"marijuana":false,"medicated":0,"member_discount":0,"member_only":0,"name":"PRODUCT Non-Cannabis TEST' + num + steps_Main.numRandom +'","price":0,"strain_id":null,"strain":null,"tax_id":null,"tax":{},"type":null,"updated_at":null,"vendor":null,"vendor_id":' + steps_Save.global_Variable['ID_Vendor'] + ',"requires_weighing":1,"shareable":true,"metrc_weighable":false,"metrc_item_association":null,"prices":[{"id":null,"quantity":"50","price":100,"post_tax":"100","pre_excise":100,"tax_category_id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"member_level_id":null,"member_discount_id":null,"type":"RETAIL_MEDICAL","tax_category":{"id":' + steps_Save.global_Variable['ID_Tax_category'] + ',"name":"TEST AUTOMATION","location_id":"' + steps_Get.global_Variable['locationput'] + '","account_id":"' + steps_Get.global_Variable['accoput'] + '","deleted_at":null,"created_at":"2019-07-22T21:16:28+00:00","updated_at":"2019-10-28T21:27:23+00:00","is_default":0,"is_exempt":0,"overall_rate":"","taxes":[]}}],"price_settings":{"id":null,"default_cost_per_unit":null,"price_point_by_usable_weight":0,"block_item_from_being_sold_below_cost_per_unit":0,"member_discount_eligible":1,"block_item_from_being_sold_at_zero_cost":0,"members_only_product":0},"packaging_detail":{"id":null,"ingredients":"","allergens":"","manufacturer_id":null,"cultivator_id":null,"activation_time":"","activation_time_unit":"","lasting_effect_time":"","lasting_effect_time_unit":"","recreational_customer_label_template_id":null,"medical_customer_label_template_id":null,"inventory_label_template_id":null,"suggested_amount":null,"serving_size":null,"serving_size_unit":"","serving_size_of_the_container":null,"product_id":null},"unit":"g","weight_per_unit_measure":"g","batch_type_id":' + str(steps_Get.global_Variable['ID_Batch_Type']) + ',"usable_weight":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Driver Request Json')
    def Modify_driver_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","firstname":"Drivername modified","lastname":"Automation","license":"12345","license_expiration":"2023-12-31","account_id": "' + steps_Get.global_Variable['accoput'] + '","created_at":"2020-02-26T21:40:17+00:00","updated_at":"2020-02-26T15:13:11+00:00","deleted_at":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Modify Vehicle Request Json')
    def Modify_vehicle_Request(self):
        jsonput = '{"id":"' + steps_Get.global_Variable['ID'] + '","name":"Vehiclename modified","color":"Black","license_plate":"102030","make":"Automation","model":"Toyota","vin_number":"001122","year":2020,"account_id": "' + steps_Get.global_Variable['accoput'] + '","created_at":"2019-09-30T18:43:34+00:00","updated_at":"2020-02-26T15:52:54+00:00","deleted_at":null}'
        http_request_body['RequestBody'] = jsonput

    @given(u'Select Inventory Audit Request Json')
    def Create_Audit_Request(self):
        jsoncreate = '{"room_id":' + steps_Save.global_Variable['ID_Room'] + ',"productCategories":[{"product_category_id":' + steps_Save.global_Variable['ID_Product_Category'] + '}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Update Audit Request Json, set new value: "{auditvalue}"')
    def Update_Audit_Request(self, auditvalue):
        global_Variable['AuditNewValue'] = auditvalue
        jsoncreate = '{"batchAuditDetails": [{"id": ' + steps_Get.global_Variable['ID_Batch_Audit'] + ', "new_value": ' + auditvalue + ', "reason_note": "Inventory Audit", "status": "AUDITED"}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Adjust Batch Request Json, and new quantity: "{newvalue}"')
    def Adjust_Batch_Request(self, newvalue):
        global_Variable['AuditNewValue'] = newvalue
        jsoncreate = '[{"batch_id": "' + steps_Get.global_Variable['ID_Batch_Aux'] + '","inventory_location_id": ' + steps_Save.global_Variable['ID_Room'] + ',"quantity": ' + newvalue + ',"adjustment_reason": "Test Automation","batch_adjustment_type_id": 1}]'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Split Batch in 2, Request Json, quantity 1: "{q1}" and quantity 2: "{q2}"')
    def Split_Batch_Request(self, q1, q2):
        global_Variable['gq1'] = q1
        global_Variable['gq2'] = q2
        global_Variable['qty'] = int(global_Variable['gq1']) + int(global_Variable['gq2'])
        jsoncreate = '[{"inventory_location_id": "' + steps_Save.global_Variable['ID_Room'] + '","quantity": ' + str(global_Variable['qty']) + ',"inventory_locations": [{"inventory_location_id": "' + steps_Save.global_Variable['ID_Room'] + '","quantity": "' + q1 + '"},{"inventory_location_id": "' + steps_Save.global_Variable['ID_Room'] + '","quantity": "' + q2 + '"}]}]'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Combine Batch Request Body')
    def Combine_Batch_Request(self):
        jsoncreate = '{"product_sku": ' + steps_Save.global_Variable['ID_Product'] + ',"strain_id": ' + steps_Save.global_Variable['ID_Strain'] + ',"state_tracking_id": null,"destination": [{"inventory_location_id": ' + steps_Save.global_Variable['ID_Room'] + ',"quantity": ' + str(global_Variable['qty']) + '}],"inventory_locations": [{"inventory_location_id": ' + steps_Save.global_Variable['ID_Room'] + ',"batch_id": "' + str(steps_Get.global_Variable['ID_Batch1']) + '","quantity": ' + global_Variable['gq1'] + '},{"inventory_location_id": ' + steps_Save.global_Variable['ID_Room'] + ',"batch_id": "' + str(steps_Get.global_Variable['ID_Batch2']) + '","quantity": ' + global_Variable['gq2'] + '}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Move Batch Request Body')
    def Move_Batch_Request(self):
        jsoncreate = '[{"batch_id": "' + steps_Save.global_Variable['ID_Batch_Aux'] + '","from_inventory_location_id": ' + steps_Save.global_Variable['ID_Room_Aux'] + ',"to_inventory_location_id": "' + steps_Save.global_Variable['ID_Room'] + '","quantity": ' + str(global_Variable['qty']) + '}]'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Convert Batch Request Body')
    def Convert_Batch(self):
        jsoncreate = '{"origin": [{"batch_id": "' + str(steps_Get.global_Variable['ID_Batch0']) + '","inventory_location_id": ' + str(steps_Save.global_Variable['ID_Room']) + ',"quantity": ' + str(global_Variable['qty']) + '}],"destination": {"product_sku": ' + str(steps_Save.global_Variable['ID_Product']) + ',"strain_id": null,"secondary_id": "","inventory_locations": [{"inventory_location_id": ' + str(steps_Save.global_Variable['ID_Room_Aux']) + ',"quantity": ' + str(global_Variable['qty']) + '}]},"options": {"usable_weight": "5","unit_measure": "g","waste": null,"pass_through_qa_results": false,"serialize": false}}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Deposit "{amount}" in Safe request body')
    def deposit_safe_Request(self, amount):
        global_Variable['Amount_Safe'] = amount
        jsoncreate = '{"user_id": ' + steps_Save.global_Variable['ID_User_Login'] + ', "manager_id": ' + steps_Save.global_Variable['ID_User_Login'] + ', "event_date": "2020-03-12 15:59:09", "type": "ADD", "amount": "' + amount + '","sub_type": "DEPOSIT_TO_SAFE", "box_id": 1}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Open Till request body')
    def Open_Till_Request(self):
        jsoncreate = '{"name": "Till' + steps_Main.global_Variable['fecha'] + ' ' + steps_Main.global_Variable['hora'] + '", "type": "TILL", "safe_id": 1, "location_id": 1, "status": "CLOSE", "assigned_user_id": ' + steps_Save.global_Variable['ID_User'] + '}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Assign Amount Till request body')
    def set_amount_till_Request(self):
        jsoncreate = '{"user_id":' + steps_Save.global_Variable['ID_User'] + ',"amount":"' + global_Variable['Amount_Safe'] + '","manager_id":' + steps_Save.global_Variable['ID_User_Login'] + '}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Add/Remove {amounttill} to Till request body')
    def set_add_till_Request(self, amounttill):
        jsoncreate = '{"amount":"' + amounttill + '","manager_id":' + steps_Save.global_Variable['ID_User_Login'] + ',"user_id":' + steps_Save.global_Variable['ID_User'] + '}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Payout {amounttill} from Till request body')
    def payout_till_Request(self, amounttill):
        jsoncreate = '{"user_id":' + steps_Save.global_Variable['ID_User'] + ',"manager_id":' + steps_Save.global_Variable['ID_User_Login'] + ',"event_date":"2020-03-16 17:39:03","type":"REMOVE","amount":"' + amounttill + '","sub_type":"PAYOUT_FROM_TILL","box_id":' + steps_Save.global_Variable['ID_Till'] + ',"description":"TEST AUTOMATION"}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Close Till request body')
    def close_till_Request(self):
        jsoncreate = '{"bills":{"ones":"","fives":"","tens":"","twenties":"","fifties":"","hundreds":""},"total_change":"","other_amount":"","review_count":0,"review_difference":0,"manager_id":' + steps_Save.global_Variable['ID_User_Login'] + '}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Toby Charge Stripe request body')
    def charge_stripe_Request(self):
        jsoncreate = '{"order_id":100453,"reference_id":402858,"currency_code":"ARS","operation_mode":"SYNC","amount":500,"country_code":"AR","id":402828,"metadata":[{"description":"Prueba Automation","variable_one":"value one","contact_email":"rene.montilla@helixtechnologies.com","account_id":1000,"stripe_id":715}],"payment_method":[{"id":"strp","parameters":[{"cc_name":"Juan Perez H","cc_number":5031755734530604,"id":"nativa","type_id":"credit_card","cc_expiration_month":11,"cc_expiration_year":2025,"cc_cs":123,"statement_descriptor":"","identification_number":35962066,"identification_type":"DNI","cc_id":14723,"created_at":"2017-02-20 11:02:32","updated_at":"2017-09-20 11:02:32"}]}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Toby Charge Mercado Pago request body')
    def charge_mp_Request(self):
        jsoncreate = '{"order_id": 100470,"currency_code": "ARS","operation_mode": "SYNC","amount": 5000,"country_code": "AR","payment_reference": [{"id": 402870,"metadata": [{"description": "Prueba Automation","variable_one": "value one","contact_email": "rene.montilla@helixtechnologies.com","account_id": 1000}]}],"payment_method": [{"id": "mercado-pago","parameters": [{"cc_name": "Juan Perez H","cc_number": 4509953566233704,"id": "visa","type_id": "credit_card","cc_expiration_month": 11,"cc_expiration_year": 2025,"cc_cs": 123,"statement_descriptor": "","identification_number": 35962066,"identification_type": "DNI","cc_id": 14723,"created_at": "2017-02-20 11:02:32","updated_at": "2017-09-20 11:02:32"}]}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Toby Charge Telecom request body')
    def charge_telecom_Request(self):
        jsoncreate = '{"order_id": 100462,"reference_id": 402862,"currency_code": "ARS","operation_mode": "SYNC","amount": 500,"country_code": "AR","payment_reference": [{"id": 402828,"metadata": [{"description": "Prueba Automation","variable_one": "value one","account_id": 1000}]}],"payment_method": [{"id": "telecom","parameters": [{"telecom_phone": 1168620666}]}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Toby ChargeOver request body')
    def charge_Over_Request(self):
        jsoncreate = '{"order_id": 100463,"reference_id": 402863,"currency_code": "ARS","operation_mode": "SYNC","amount": 500,"country_code": "AR","payment_reference": [{"id": 402829,"metadata": [{"description": "Prueba Automation","variable_one": "value one","contact_email": "rene.montilla@helixtechnologies.com","account_id": 1850}]}],"payment_method": [{"id": "chargeover","parameters": [{"cc_name": "Juan Perez H","cc_number": 5031755734530604,"id": "visa","type_id": "credit_card","cc_expiration_month": 11,"cc_expiration_year": 2025,"cc_cs": 123,"statement_descriptor": "","cc_id": 12345,"created_at": "2017-02-20 11:02:32","updated_at": "2017-09-20 11:02:32","contact_name": "Juan Perez H","business_name":"HELIX","address": "La oficina 123","city": "Buenos Aires","state": "Buenos Aires","postcode": 12345,"phone1": 1122334455}]}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Order Create request body, quantity product: {qprod}')
    def Order_Create_Request(self, qprod):
        jsoncreate = '{"id":null,"customer_id":' + steps_Save.global_Variable['ID_Customer_Patient'] + ',"order_items":[{"batch_barcode_uid":"' + steps_Get.global_Variable['ID_Batch_Aux'] + '","quantity":' + qprod + '}]}'
        http_request_body['RequestBody'] = jsoncreate
        global_Variable['qprobatch'] = int(qprod)

    @given(u'Select Order Confirm request body')
    def Order_Confirm_Request(self):
        jsoncreate = '{"order_payments":[{"payment_method_id":3,"amount":5,"order_id":' + steps_Save.global_Variable['ID_Order'] + '}],"caregiver_id":null,"applied_discounts":[]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Add Manual Discount: "{percentage}", request body')
    def Manual_Discount_Request(self, percentage):
        jsoncreate = '{"id": ' + steps_Save.global_Variable['ID_Order'] + ',"customer_id": ' + steps_Save.global_Variable['ID_Customer_Patient'] + ',"order_items": [{"id": ' + steps_Get.global_Variable['ID_Order_Global'] + ',"batch_barcode_uid": "' + steps_Get.global_Variable['ID_Batch_Aux'] + '","quantity": ' + str(global_Variable['qprobatch']) + ' }],"applied_discounts": [{"description": "TEST AUTOMATION","amount": "' + percentage + '","discount_id": ' + str(steps_Get.global_Variable['M_Discount_Per']) + '}],"caregiver_id": null}'
        http_request_body['RequestBody'] = jsoncreate
        global_Variable['Per_discount'] = percentage

    @given(u'Select Order Confirm Discounts, request body')
    def Order_Confirm_Discounts_Request(self):
        jsoncreate = '{"order_payments": [{"payment_method_id": 3,"amount": 5,"order_id": ' + steps_Save.global_Variable['ID_Order'] + '}],"caregiver_id": null,"applied_discounts": [{"amount": "' + str(global_Variable['Per_discount']) + '","discount_id": ' + str(steps_Get.global_Variable['M_Discount_Per']) + ',"scope": "' + steps_Get.global_Variable['Scope_discount'] + '","auto_apply_quantity": 1,"effective_quantity": 1, "applicable_amount": 1,"codename": "' + steps_Get.global_Variable['Codename_discount'] + '"}]}'
        http_request_body['RequestBody'] = jsoncreate

    @given(u'Select Order Refund request body, quantity refund: {qrefund}')
    def Order_Refund_Request(self, qrefund):
        jsoncreate = '{"order_items":[{"id":' + steps_Get.global_Variable['ID_Order_Global'] + ',"quantity":' + qrefund + ',"action":"REFUND"}]}'
        http_request_body['RequestBody'] = jsoncreate
        global_Variable['qprobatch'] = int(qrefund)

    @given(u'Select Order Update Create request body, quantity product: {qprod}')
    def Order_Create_Request(self, qprod):
        jsoncreate = '{"id":' + steps_Save.global_Variable['ID_Order'] + ',"customer_id":' + steps_Save.global_Variable['ID_Customer_Patient'] + ',"order_items":[{"batch_barcode_uid":"' + steps_Get.global_Variable['ID_Batch_Aux'] + '","quantity":' + qprod + '}],"applied_discounts":[],"caregiver_id":null}'
        http_request_body['RequestBody'] = jsoncreate
        global_Variable['qprobatch'] = int(qprod)

    @given(u'Select Order Refund Confirm request body')
    def Order_Confirm_Refund_Request(self):
        jsoncreate = '{"order_payments":[{"payment_method_id":3,"amount":0,"order_id":' + steps_Save.global_Variable['ID_Order'] + '}],"caregiver_id":null,"applied_discounts":[]}'
        http_request_body['RequestBody'] = jsoncreate


