from behave import *
from steps import steps_Save, steps_Main, steps_Get, steps_Requests_Body


class stpSet():

    @given(u'Set Password: "{password}"')
    def set_password(self, password):
        steps_Requests_Body.global_Variable['Pass_User'] = str(password)

    @given(u'Set ID of Customer Patient')
    def set_ID_Custo_patient(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Customer_Patient']

    @given(u'Set ID of Customer Caregiver')
    def set_ID_Custo_patient(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Customer_Caregiver']

    @given(u'Set ID Room')
    def set_ID_Room(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Room']

    @given(u'Set ID Room Aux')
    def set_ID_Room(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Room_Aux']

    @given(u'Set ID Brand')
    def set_ID_Brand(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Brand']

    @given(u'Set ID Strain')
    def set_ID_Strain(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Strain']

    @given(u'Set ID Vendor')
    def set_ID_Vendor(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Vendor']

    @given(u'Set ID Tax category')
    def set_ID_Tax_category(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Tax_category']

    @given(u'Set ID Member level')
    def set_ID_Member_level(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Member_level']

    @given(u'Set ID Product Category')
    def set_ID_Product_Category(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Product_Category']

    @given(u'Set ID Product')
    def set_ID_Product(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Product']

    @given(u'Set ID Batches')
    def set_ID_Batches(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Batches']

    @given(u'Set ID Batches OP')
    def set_ID_Batches(self):
        steps_Get.global_Variable['ID'] = steps_Get.global_Variable['ID_Batches']

    @given(u'Set ID Batch')
    def set_ID_Batch(self):
        steps_Get.global_Variable['ID_Batch'] = steps_Get.global_Variable['ID_Batch_Aux']

    @given(u'Set ID User')
    def set_ID_User(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_User']

    @given(u'Set ID Till')
    def set_ID_Till(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Till']

    @given(u'Set Token {tok}')
    def set_Token(self, tok):
        steps_Get.global_Variable['ACToken'] = str(tok)

    @given(u'Set ID Order')
    def set_ID_Order(self):
        steps_Get.global_Variable['ID'] = steps_Save.global_Variable['ID_Order']

    @given(u'Set Order Number')
    def set_ID_Order(self):
        steps_Get.global_Variable['ID'] = steps_Get.global_Variable['Order_number']

    @given(u'Set ID Order Global')
    def set_ID_Order_Global(self):
        steps_Get.global_Variable['ID'] = steps_Get.global_Variable['ID_Order_Global']